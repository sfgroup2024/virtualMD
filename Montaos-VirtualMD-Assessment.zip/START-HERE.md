# VirtualMD — Technical Assessment

Hi Russel,

This is the technical assessment. Everything you need is in this folder —
no other files, no further instructions to wait for.

**One thing worth being direct about:** this isn't a hypothetical exercise dressed
up to look urgent. Doctor payouts on our live platform have not worked correctly
since launch, and the specific bug in Part 2 is close to our actual, current,
real-money problem. If anything here feels oddly specific, that's why.

## Timing

The clock starts when we agree it does. From that moment you have a **hard three
hours** to work and send back what you have. We won't be available to answer
questions once you've started — if something's ambiguous, write down the
assumption you made and keep going. That's a normal part of the job too.

There is genuinely more here than most people finish in three hours, even using AI
well. That's intentional. Use your judgment about where to spend your time, and
tell us what you decided to skip and why — that decision is part of what we're
evaluating, not a failure to complete something.

**Use whatever tools you'd normally use, including AI assistants.** We use them
ourselves. You're responsible for every line you send us — if something is wrong,
unnecessary, or doesn't match how the rest of the code is written, that counts
against you regardless of what produced it.

---

## Part 1 — Triage (do this first, ~20 minutes, written)

It's Monday morning. You've just joined as our only backend engineer. Here is
everything currently wrong. You have one week, working alone. Tell us what you
do, in what order, and why. **Two pages maximum**, in your submission document.

1. Doctors have never been paid. Every payout attempt through our payment
   provider has failed for months. The job runs daily and reports success.
2. Doctors set their availability in the app, get a success message, but the
   data never saves. Patients can't book them. No error appears anywhere.
3. Our SSL certificate expired last week. The site was down until a user
   reported it.
4. Patients don't receive their consultation summary emails. The in-app summary
   screen is blank.
5. Bot signups are creating fake accounts, and each one may be consuming paid
   AI credits.
6. Our AI spend auto-tops-up $30 a day with no cap and nobody watching.

Also tell us: **which of these are engineering problems, and which aren't?**
Be direct if you think some aren't yours to fix.

## Part 2 — Backend (`backend/`)

A booking and doctor-payout service.

```bash
cd backend
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open **http://127.0.0.1:8000/docs**. Full brief: `backend/README.md`.

Find the real bugs in `app/payouts.py`, `app/commission.py`, and `app/booking.py`.
For each: where it is, what actually goes wrong (use real numbers from the
seeded data), why it matters, and a severity rating. Fix what you have time for
— minimal, targeted diffs, no new dependencies, no rewrites beyond what's
actually broken.

One of these bugs won't show up from calling the API a normal number of times —
only under concurrent requests. If you find it, explain how you'd test for it,
even without a fix.

## Part 3 — Frontend (`frontend/`)

Build the admin page our operations team needs, using the backend you just spent
time in.

```bash
cd frontend
npm install
npm run dev
```

Full brief: `frontend/PAGE-BRIEF.md`. Leave Part 2's `uvicorn` running (or
restart it) — the frontend needs the live backend.

## Part 4 — Mobile (`mobile/`)

A screen from our doctor app. Reading and analysis only, no emulator needed.

```bash
cd mobile
flutter pub get
flutter analyze
```

Full brief: `mobile/README.md`.

## Comments

**For every fix you make, add a short inline comment explaining why the
original code was wrong** — not what your new code does, why the old version
was a bug. This applies in all three code parts.

---

## Submitting

**Create a new, private repository under your own GitHub account** and commit
your work there as you go — real commits as you progress through each part,
not one commit at the end. That gives us a sense of your process, not just
your result.

When you're done, **invite `@ronshairubin1` as a collaborator** on that repo,
and reply to the email this came with, with the repo link and your written
report — one document, covering: your Part 1 triage, and for Parts 2–4,
findings, severity, what you fixed, and what you'd have done with more time.

Two more things for that report:

- **One thing you initially got wrong or missed, and how you noticed.**
  Everyone doing this properly has one — we'd rather see it than a report that
  reads like nothing went sideways.
- **If you could only fix one of the six backend bugs before anything else,
  which one, and why** — in your own words, not just by severity label.

Please don't push anything into any of our own repositories or organizations
— this should be entirely your own, separate repo.

Talk soon,
Ron
