// The backend runs on http://127.0.0.1:8000 (see the main README).
// Start it first: uvicorn app.main:app --reload
export const API_BASE = 'http://127.0.0.1:8000'

export async function fetchDoctors() {
  const res = await fetch(`${API_BASE}/doctors`)
  if (!res.ok) throw new Error(`GET /doctors failed: ${res.status}`)
  return res.json()
}

export async function runPayouts() {
  const res = await fetch(`${API_BASE}/payouts/run`, { method: 'POST' })
  if (!res.ok) throw new Error(`POST /payouts/run failed: ${res.status}`)
  return res.json()
}
