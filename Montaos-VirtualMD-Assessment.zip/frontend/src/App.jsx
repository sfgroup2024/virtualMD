// This is your starting point. Build the Doctor Payouts admin page here
// (or split into components — your call). See PAGE-BRIEF.md for what to build.
export default function App() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: 24 }}>
      <h1>Doctor Payouts</h1>
      <p>Start here.</p>
    </div>
  )
}
