# Part 1 — Backend

(Logistics — timing, comments, how to submit — are in the top-level `README.md`.
This file is just the backend-specific brief.)

## Setup

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Then open **http://127.0.0.1:8000/docs** — an interactive page where you can call
every endpoint directly. A SQLite database is created and seeded automatically the
first time you run it. Delete `virtualmd_test.db` for a clean slate.

Leave this running — Part 2's frontend needs it.

## The situation

Doctors have told us they aren't being paid correctly. Some think they're owed
more than they're getting, some less. Separately, our operations team mentioned
that when they re-run the payout job manually — which they do whenever something
looks wrong — the numbers don't behave the way they'd expect.

There's also a booking complaint: two patients both believe they successfully
booked the same appointment slot with the same doctor.

The code is `app/payouts.py`, `app/commission.py`, `app/booking.py`, and
`app/main.py` (which wires all three into the API you'll be calling).
`app/models.py` and `app/seed.py` show you the data.

## What to find

List every real defect. For each: where it is, what actually goes wrong (use real
numbers — "Dr. X's balance should be ₱Y but the code produces ₱Z" is exactly what
we want), why it matters, and a severity rating.

One of these won't show up from calling the API a normal number of times — it
only shows up under **concurrent** requests. If you find it, explain how you'd
test for it and why it's a race, even if you don't have time to fix it.
