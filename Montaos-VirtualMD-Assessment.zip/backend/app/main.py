"""VirtualMD — trimmed booking & payouts service.

Run with:  uvicorn app.main:app --reload
Then open: http://127.0.0.1:8000/docs
"""
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app.database import Base, engine, SessionLocal, get_db
from app.models import Doctor
from app.payouts import run_payout_batch, payable_balance, PaymentGateway
from app.booking import book_slot, SlotUnavailableError
from app.commission import price_booking
from app.seed import seed_if_empty

Base.metadata.create_all(bind=engine)
_seed_db = SessionLocal()
seed_if_empty(_seed_db)
_seed_db.close()

app = FastAPI(title="VirtualMD Booking & Payouts (test build)")

# The React dev server runs on a different port (5173) during local dev.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def root():
    return RedirectResponse(url="/docs")


@app.get("/doctors")
def list_doctors(db: Session = Depends(get_db)):
    """All doctors with their current payable balance. Powers the admin page."""
    return [
        {
            "id": d.id,
            "name": d.name,
            "email": d.email,
            "payable_balance": payable_balance(db, d),
        }
        for d in db.query(Doctor).all()
    ]


@app.get("/doctors/{doctor_id}/balance")
def get_balance(doctor_id: int, db: Session = Depends(get_db)):
    doctor = db.query(Doctor).filter(Doctor.id == doctor_id).first()
    if doctor is None:
        raise HTTPException(404, "no such doctor")
    return {"doctor": doctor.name, "email": doctor.email, "payable_balance": payable_balance(db, doctor)}


@app.post("/payouts/run")
def run_payouts(db: Session = Depends(get_db)):
    """Manually trigger a payout run. This is what ops re-runs when a
    doctor reports they haven't been paid."""
    gateway = PaymentGateway(funded=True)
    result = run_payout_batch(db, gateway)
    result["disbursements"] = gateway.sent
    return result


@app.post("/slots/{slot_id}/book")
def book(slot_id: int, patient_name: str = "Test Patient", db: Session = Depends(get_db)):
    try:
        slot = book_slot(db, slot_id, patient_name)
    except SlotUnavailableError as e:
        raise HTTPException(409, str(e))
    return {"slot_id": slot.id, "booked": slot.booked}


@app.get("/pricing/preview")
def pricing_preview(doctor_fee: float):
    """What a patient would pay, and what the platform keeps, for a given
    doctor fee. Used when a doctor sets or changes their consultation fee."""
    return price_booking(doctor_fee)
