"""Seed data. Runs once on startup if the database is empty."""
from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from app.models import Doctor, Appointment, AvailabilitySlot


def seed_if_empty(db: Session):
    if db.query(Doctor).first() is not None:
        return

    now = datetime.now()

    aileen = Doctor(email="aileen.cruz@example.com", name="Dr. Aileen Cruz", consultation_fee=500)
    marco = Doctor(email="marco.reyes@example.com", name="Dr. Marco Reyes", consultation_fee=750)
    bea = Doctor(email="bea.santos@example.com", name="Dr. Bea Santos", consultation_fee=600)
    carlo = Doctor(email="carlo.diaz@example.com", name="Dr. Carlo Diaz", consultation_fee=500)

    db.add_all([aileen, marco, bea, carlo])
    db.commit()

    appointments = [
        # Dr. Aileen — three straightforward completed appointments, well past the hold.
        Appointment(doctor_id=aileen.id, doctor_email="aileen.cruz@example.com",
                    patient_name="Patient A1", status="completed", doctor_net=500,
                    completed_at=now - timedelta(days=10)),
        Appointment(doctor_id=aileen.id, doctor_email="aileen.cruz@example.com",
                    patient_name="Patient A2", status="completed", doctor_net=500,
                    completed_at=now - timedelta(days=8)),
        Appointment(doctor_id=aileen.id, doctor_email="aileen.cruz@example.com",
                    patient_name="Patient A3", status="completed", doctor_net=500,
                    completed_at=now - timedelta(days=6)),

        # Dr. Marco — two completed consultations.
        Appointment(doctor_id=marco.id, doctor_email="marco.reyes@example.com",
                    patient_name="Patient M1", status="completed", doctor_net=750,
                    completed_at=now - timedelta(days=9)),
        Appointment(doctor_id=marco.id, doctor_email="Marco.Reyes@example.com",
                    patient_name="Patient M2", status="completed", doctor_net=750,
                    completed_at=now - timedelta(days=5)),

        # Dr. Bea — a completed consultation and a no-show.
        Appointment(doctor_id=bea.id, doctor_email="bea.santos@example.com",
                    patient_name="Patient B1", status="completed", doctor_net=600,
                    completed_at=now - timedelta(days=7)),
        Appointment(doctor_id=bea.id, doctor_email="bea.santos@example.com",
                    patient_name="Patient B2", status="no_show", doctor_net=600,
                    completed_at=now - timedelta(days=4)),

        # Dr. Carlo — a single, more recent consultation.
        Appointment(doctor_id=carlo.id, doctor_email="carlo.diaz@example.com",
                    patient_name="Patient C1", status="completed", doctor_net=500,
                    completed_at=now - timedelta(days=1)),
    ]
    db.add_all(appointments)

    slots = [
        AvailabilitySlot(doctor_id=aileen.id, slot_time=now + timedelta(days=1, hours=9), booked=False),
        AvailabilitySlot(doctor_id=aileen.id, slot_time=now + timedelta(days=1, hours=10), booked=False),
        AvailabilitySlot(doctor_id=marco.id, slot_time=now + timedelta(days=2, hours=14), booked=True),
    ]
    db.add_all(slots)
    db.commit()
