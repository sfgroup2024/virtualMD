"""Doctor payout batch job. Runs daily (or on demand via the API) and pays
every doctor whatever they're owed for completed consultations, once the
3-day hold has passed.
"""
from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from app.models import Doctor, Appointment

HOLD_DAYS = 3


class GatewayError(Exception):
    pass


class PaymentGateway:
    """Stand-in for our real payment provider."""

    def __init__(self, funded: bool = True):
        self.funded = funded
        self.sent = []

    def disburse(self, doctor_email: str, amount: float) -> dict:
        if not self.funded:
            raise GatewayError("settlement account not attached")
        self.sent.append({"doctor_email": doctor_email, "amount": amount})
        return {"status": "sent", "id": f"dsb_{len(self.sent)}"}


def payable_appointments(db: Session, doctor: Doctor):
    """Appointments that should be paid out right now for this doctor."""
    cutoff = datetime.now() - timedelta(days=HOLD_DAYS)
    results = []
    for appt in db.query(Appointment).all():
        if appt.doctor_email != doctor.email:
            continue
        if appt.status not in ("completed", "no_show"):
            continue
        if appt.completed_at > cutoff:
            continue
        results.append(appt)
    return results


def payable_balance(db: Session, doctor: Doctor) -> float:
    appts = payable_appointments(db, doctor)
    return sum(a.doctor_net for a in appts)


def run_payout_batch(db: Session, gateway: PaymentGateway) -> dict:
    """Pay every doctor what they're owed. Called daily by our scheduler,
    and also exposed via POST /payouts/run for manual re-runs when a doctor
    reports a problem.
    """
    paid_count = 0
    total_paid = 0.0

    for doctor in db.query(Doctor).all():
        amount = payable_balance(db, doctor)
        if amount <= 0:
            continue
        try:
            gateway.disburse(doctor.email, amount)
            for appt in payable_appointments(db, doctor):
                appt.paid = True
            paid_count += 1
            total_paid += amount
        except GatewayError:
            pass

    db.commit()
    return {"doctors_paid": paid_count, "total_paid": total_paid}
