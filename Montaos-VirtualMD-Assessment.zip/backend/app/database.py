"""Database setup. SQLite file, no external services required."""
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

DATABASE_URL = "sqlite:///./virtualmd_test.db"

# pool_size/max_overflow raised well above SQLAlchemy's default (5+10) — this is
# a single-file SQLite demo hit repeatedly via /docs, not a real deployment.
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},
    pool_size=20,
    max_overflow=40,
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
