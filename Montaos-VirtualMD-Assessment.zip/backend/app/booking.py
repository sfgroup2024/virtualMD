"""Slot booking. A patient picks an open slot; we mark it booked."""
from sqlalchemy.orm import Session

from app.models import AvailabilitySlot


class SlotUnavailableError(Exception):
    pass


def book_slot(db: Session, slot_id: int, patient_name: str) -> AvailabilitySlot:
    slot = db.query(AvailabilitySlot).filter(AvailabilitySlot.id == slot_id).first()
    if slot is None:
        raise SlotUnavailableError("no such slot")

    if slot.booked:
        raise SlotUnavailableError("slot already booked")

    # (patient_name isn't persisted anywhere in this trimmed-down version —
    # the real system creates an Appointment here. Not the point of this test.)
    slot.booked = True
    db.commit()
    return slot
