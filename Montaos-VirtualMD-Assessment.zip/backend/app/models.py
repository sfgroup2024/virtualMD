"""Database models — doctors, appointments, availability slots."""
from datetime import datetime

from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey
from sqlalchemy.orm import relationship

from app.database import Base


class Doctor(Base):
    __tablename__ = "doctors"

    id = Column(Integer, primary_key=True)
    email = Column(String, nullable=False)
    name = Column(String, nullable=False)
    consultation_fee = Column(Float, nullable=False)  # PHP, set by the doctor

    appointments = relationship("Appointment", back_populates="doctor")


class Appointment(Base):
    __tablename__ = "appointments"

    id = Column(Integer, primary_key=True)
    doctor_id = Column(Integer, ForeignKey("doctors.id"), nullable=False)
    doctor_email = Column(String, nullable=False)  # denormalized, as our real system does
    patient_name = Column(String, nullable=False)
    status = Column(String, nullable=False)  # completed | no_show | cancelled | expired
    doctor_net = Column(Float, nullable=False)  # PHP owed to the doctor for this appointment
    completed_at = Column(DateTime, nullable=False)
    paid = Column(Boolean, default=False)

    doctor = relationship("Doctor", back_populates="appointments")


class AvailabilitySlot(Base):
    __tablename__ = "availability_slots"

    id = Column(Integer, primary_key=True)
    doctor_id = Column(Integer, ForeignKey("doctors.id"), nullable=False)
    slot_time = Column(DateTime, nullable=False)
    booked = Column(Boolean, default=False)
