"""Pricing: what the platform charges on top of a doctor's fee."""

MARKUP_RATE = 0.40
MIN_MARKUP_PHP = 100


def price_booking(doctor_fee: float) -> dict:
    """Given a doctor's fee, return what the patient pays and what we keep.

    The doctor is always paid the fee they set, in full. Our markup rides on
    top, floored at MIN_MARKUP_PHP so small consultations still cover our costs.
    """
    if doctor_fee <= 0:
        return {"patient_total": 0, "platform_fee": 0, "doctor_fee": 0}

    markup = max(MIN_MARKUP_PHP, doctor_fee * MARKUP_RATE // 1)
    patient_total = doctor_fee + markup

    return {
        "patient_total": patient_total,
        "platform_fee": markup,
        "doctor_fee": doctor_fee,
    }
